
const labels={birthdays:'تولد / سالگرد',appointments:'قرار / یادآوری',tasks:'کار روزانه',payments:'پرداخت / قسط'};const icons={birthdays:'🎂',appointments:'📅',tasks:'✓',payments:'💳'};let data=(()=>{try{const parsed=JSON.parse(localStorage.getItem('yadaData')||'{"birthdays":[],"appointments":[],"tasks":[],"payments":[]}');return parsed&&typeof parsed==='object'&&!Array.isArray(parsed)?parsed:{birthdays:[],appointments:[],tasks:[],payments:[]}}catch(e){return {birthdays:[],appointments:[],tasks:[],payments:[]}}})();
for(const k of ['birthdays','appointments','tasks','payments'])if(!Array.isArray(data[k]))data[k]=[];
let financeData=(()=>{try{return JSON.parse(localStorage.getItem('yadaFinance')||'{"transactions":[],"debts":[],"monthlyBudget":0,"categoryBudgets":{}}')}catch(e){return {transactions:[],debts:[],monthlyBudget:0,categoryBudgets:{}}}})();if(!financeData||typeof financeData!=='object')financeData={transactions:[],debts:[],monthlyBudget:0,categoryBudgets:{}};
function parseJalaliSafe(value){try{return parseJalali(value)||''}catch(e){return ''}}
function normalizeFinanceAmount(value){
 let s=String(value??'').trim()
  .replace(/[۰-۹]/g,c=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(c))
  .replace(/[٠-٩]/g,c=>'٠١٢٣٤٥٦٧٨٩'.indexOf(c))
  .replace(/[٬,،\s]/g,'')
  .replace(/تومان|ریال/g,'')
  .replace(/[^0-9.\-]/g,'');
 let n=Number(s);
 return Number.isFinite(n)&&n>=0?n:0;
}
function unformatFinanceInput(input){input.value=String(input.value||'').replace(/[٬,،\s]/g,'').replace(/[۰-۹]/g,c=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(c)).replace(/[٠-٩]/g,c=>'٠١٢٣٤٥٦٧٨٩'.indexOf(c))}
function formatFinanceInput(input){const raw=String(input.value||'').trim();const n=normalizeFinanceAmount(raw);input.value=raw&&n?new Intl.NumberFormat('fa-IR',{maximumFractionDigits:0}).format(n):''}
function formatAmountTyping(input){const raw=String(input.value||'');if(!raw.trim()){input.value='';return}const n=normalizeFinanceAmount(raw);const formatted=n?new Intl.NumberFormat('fa-IR',{maximumFractionDigits:0}).format(n):'';input.value=formatted;try{input.setSelectionRange(formatted.length,formatted.length)}catch(e){}}
financeData.transactions=(Array.isArray(financeData.transactions)?financeData.transactions:[]).map(x=>({...x,type:x.type==='income'?'income':x.type==='expense'?'expense':(String(x.category||'').includes('درآمد')?'income':'expense'),date:(/^\d{4}-\d{2}-\d{2}$/.test(String(x.date||''))?x.date:(parseJalaliSafe(x.date)||x.date)),amount:normalizeFinanceAmount(x.amount)}));
financeData.debts=(Array.isArray(financeData.debts)?financeData.debts:[]).map(x=>({...x,amount:normalizeFinanceAmount(x.amount)}));if(!financeData.categoryBudgets||typeof financeData.categoryBudgets!=='object')financeData.categoryBudgets={};
let financeType='expense';let currentView='home';let currentMonthType='birthdays',selectedMonth=null,monthPage=0;
let appTheme=localStorage.getItem('yadaTheme')||'dark';
function applyTheme(){
 document.body.dataset.theme=appTheme;
 const light=appTheme==='light';
 document.getElementById('themeBtn').textContent=light?'☾':'☀';
 document.getElementById('themeBtn').setAttribute('aria-label',light?'فعال‌سازی تم تیره':'فعال‌سازی تم روشن');
 if(window.AndroidYada&&AndroidYada.setSystemBarsLight)AndroidYada.setSystemBarsLight(light);
 document.querySelector('meta[name="theme-color"]').content=light?'#f4f1e9':'#0b1222';
}
applyTheme();
function toggleTheme(){appTheme=appTheme==='dark'?'light':'dark';localStorage.setItem('yadaTheme',appTheme);applyTheme()}
const fa=n=>new Intl.NumberFormat('fa-IR').format(n);function formatFinanceMoney(value){const n=Number(value);return new Intl.NumberFormat('fa-IR',{maximumFractionDigits:0}).format(Number.isFinite(n)?Math.round(n):0)+' تومان'}function save(){localStorage.setItem('yadaData',JSON.stringify(data));render()}
// تبدیل تقویم جلالی به میلادی برای ذخیره‌سازی استاندارد و نمایش شمسی
function jalaliToGregorian(jy,jm,jd){jy=+jy;jm=+jm;jd=+jd;let gy=jy+621;let days=[0,31,59,90,120,151,181,212,243,273,304,334];let leapJ=-14;let j=y=>{let r=0;for(let i=jy-1;i>=-61;i-=1){r+=365+((i%33===1||i%33===5||i%33===9||i%33===13||i%33===17||i%33===22||i%33===26||i%33===30)?1:0);if(i<jy-1)break}return r};let jy2=jy-979;let jDay=365*jy2+Math.floor(jy2/33)*8+Math.floor((jy2%33+3)/4)+ (jm<=7?(jm-1)*31:((jm-1)*30+6))+(jd-1);let gDay=jDay+79;let gy2=1600+400*Math.floor(gDay/146097);gDay%=146097;let leap=true;if(gDay>=36525){gDay--;gy2+=100*Math.floor(gDay/36524);gDay%=36524;if(gDay>=365)gDay++;else leap=false}gy2+=4*Math.floor(gDay/1461);gDay%=1461;if(gDay>=366){leap=false;gDay--;gy2+=Math.floor(gDay/365);gDay%=365}let sal=[0,31,(leap?29:28),31,30,31,30,31,31,30,31,30,31];let gm=1;while(gm<=12&&gDay>=sal[gm]){gDay-=sal[gm];gm++}return `${gy2}-${String(gm).padStart(2,'0')}-${String(gDay+1).padStart(2,'0')}`}
function parseJalali(v){let normalized=String(v||'').trim().replace(/[۰-۹٠-٩]/g,ch=>String('۰۱۲۳۴۵۶۷۸۹'.indexOf(ch)>=0?'۰۱۲۳۴۵۶۷۸۹'.indexOf(ch):'٠١٢٣٤٥٦٧٨٩'.indexOf(ch)));let m=normalized.match(/^(\d{4})[\/\-.](\d{1,2})[\/\-.](\d{1,2})$/);if(!m)return null;let y=+m[1],mo=+m[2],d=+m[3];if(mo<1||mo>12||d<1||d>(mo<=6?31:mo<=11?30:30))return null;let iso=jalaliToGregorian(y,mo,d);let dt=new Date(iso+'T12:00:00');if(isNaN(dt.getTime()))return null;try{let parts=new Intl.DateTimeFormat('en-u-ca-persian-nu-latn',{year:'numeric',month:'numeric',day:'numeric'}).formatToParts(dt);let got={};parts.forEach(x=>got[x.type]=x.value);if(+got.year!==y||+got.month!==mo||+got.day!==d)return null}catch(e){}return iso}
function toJalaliInput(iso){if(!iso)return '';let f=new Intl.DateTimeFormat('en-u-ca-persian',{year:'numeric',month:'2-digit',day:'2-digit'});let parts=f.formatToParts(new Date(iso+'T12:00:00'));let o={};parts.forEach(x=>o[x.type]=x.value);return `${o.year}/${o.month}/${o.day}`}
function toFaDigits(v){return String(v).replace(/[0-9]/g,c=>'۰۱۲۳۴۵۶۷۸۹'[Number(c)]).replace(/[,٬]/g,'')}function fmt(d){if(!d)return 'بدون تاریخ';try{let p=jalaliParts(new Date(d+'T12:00:00'));return `${fa(p.day)} ${jalaliMonths[p.month-1]} ${fa(p.year)}`}catch(e){return d}}
const todayParts=new Intl.DateTimeFormat('fa-IR-u-ca-persian',{weekday:'long',day:'numeric',month:'long',year:'numeric'}).formatToParts(new Date());const todayValue={};todayParts.forEach(p=>todayValue[p.type]=p.value);document.getElementById('today').textContent=`${todayValue.weekday} ${todayValue.day} ${todayValue.month} ${todayValue.year}`;
function setSeasonalHero(){const month=jalaliParts(new Date()).month;const season=month<=3?'spring':month<=6?'summer':month<=9?'autumn':'winter';const names={spring:'بهار',summer:'تابستان',autumn:'پاییز',winter:'زمستان'};const mark=document.getElementById('seasonalHero');if(mark){mark.src='season-'+season+'.png';mark.alt='شاخه درخت در فصل '+names[season];mark.setAttribute('aria-label',mark.alt)}}
setSeasonalHero();
function showView(v,btn){
 if(['birthdays','appointments','tasks','payments'].includes(v)){currentMonthType=v;v='months';selectedMonth=null}
 document.body.classList.toggle('home-fit',v==='home');document.body.classList.toggle('month-fit',v==='months');document.body.classList.toggle('settings-fit',v==='settings');
 currentView=v==='months'?currentMonthType:v;
 document.querySelectorAll('.view').forEach(x=>x.classList.toggle('active',x.id===v));
 document.querySelectorAll('.nav button').forEach(x=>x.classList.remove('active'));
 if(btn)btn.classList.add('active');else{const idx=v==='home'?0:(v==='months'?1:-1);if(idx>=0)document.querySelectorAll('.nav button')[idx]?.classList.add('active')}
 const financeShortcut=document.getElementById('financeShortcut');if(financeShortcut)financeShortcut.classList.toggle('active',v==='finance');
 const fab=document.querySelector('.fab');if(fab)fab.style.display='grid';
 if(v==='months')renderMonths();if(v==='finance'){showFinanceTab('overview');renderFinance();}if(v==='settings')showSettingsTab('appearance',document.querySelector('.settings-tabs button'));
 if(v==='home'){render();window.scrollTo(0,0);requestAnimationFrame(()=>window.scrollTo(0,0));}
}
function handleFabClick(){if(currentView==='finance'){document.getElementById('financeChooser').style.display='flex'}else{openAddChooser()}}
function openAddChooser(){document.getElementById('addChooser').style.display='flex'}
function closeAddChooser(){document.getElementById('addChooser').style.display='none'}
function chooseAddType(type){closeAddChooser();currentView=type;openAdd(type)}

function normalizeTime24(v){let x=String(v||'').trim().replace(/[۰-۹]/g,c=>'۰۱۲۳۴۵۶۷۸۹'.indexOf(c)).replace(/[٠-٩]/g,c=>'٠١٢٣٤٥٦٧٨٩'.indexOf(c));if(!x)return '';let m=x.match(/^(\d{1,2}):(\d{2})$/);if(!m)return null;let h=+m[1],mi=+m[2];if(h<0||h>23||mi<0||mi>59)return null;return String(h).padStart(2,'0')+':'+String(mi).padStart(2,'0')}
function openAdd(v){if(!data[v])v=currentMonthType||'appointments';currentView=v;document.getElementById('modalTitle').textContent='افزودن '+labels[v];document.getElementById('titleInput').value='';document.getElementById('dateInput').value=jalaliToday();document.getElementById('dateInput').placeholder='امروز';document.getElementById('timeInput').value='';document.getElementById('timeHour').value='';document.getElementById('timeMinute').value='';document.getElementById('amountInput').value='';document.getElementById('noteInput').value='';document.getElementById('amountField').style.display=v==='payments'?'grid':'none';document.getElementById('monthlyRepeatField').style.display=v==='payments'?'grid':'none';document.getElementById('monthlyRepeatInput').checked=false;document.getElementById('timeField').style.display='grid';document.getElementById('dateLabel').textContent=v==='birthdays'?'تاریخ تولد شمسی (هر سال یادآوری شود)':'تاریخ شمسی (سال/ماه/روز)';document.getElementById('modal').style.display='flex'}function closeModal(){document.getElementById('modal').style.display='none'}
async function saveItem(){
 const title=document.getElementById('titleInput').value.trim();
 if(!title){alert('لطفاً عنوان را وارد کن.');return}
 const jalaliDate=document.getElementById('dateInput').value.trim();
 const isoDate=jalaliDate?parseJalali(jalaliDate):'';
 if(jalaliDate&&!isoDate){alert('تاریخ واردشده معتبر نیست. لطفاً تاریخ شمسی را به شکل سال/ماه/روز انتخاب کن؛ نمونه: ۱۴۰۵/۰۸/۲۲');return}
 const time=getSelectedEventTime();
 if(time===null){alert('ساعت انتخاب‌شده معتبر نیست.');return}
 const isBirthday=currentView==='birthdays';
 let scheduledDate=null;
 if(isoDate){
  scheduledDate=new Date(isoDate+'T'+(time||'09:00')+':00');
  if(isBirthday){const now=new Date();scheduledDate.setFullYear(now.getFullYear());if(scheduledDate<=now)scheduledDate.setFullYear(now.getFullYear()+1)}
  // تاریخ/ساعت گذشته را پیش از ساخت آیتم و پیش از ذخیره‌سازی رد می‌کنیم.
  if(!Number.isFinite(scheduledDate.getTime())||scheduledDate.getTime()<=Date.now()){
   alert('تاریخ یا ساعت انتخاب‌شده گذشته است. لطفاً زمان آینده را انتخاب کن؛ هیچ موردی ثبت نشد.');
   return;
  }
 }
 const item={id:Date.now(),title,date:isoDate,time,note:document.getElementById('noteInput').value.trim(),amount:normalizeFinanceAmount(document.getElementById('amountInput').value),done:false,monthlyRepeat:isBirthday?false:(currentView==='payments'&&document.getElementById('monthlyRepeatInput').checked),reminderAt:0};
 if(isoDate&&window.AndroidYada&&scheduledDate){
  item.reminderAt=scheduledDate.getTime();
  let exact=window.AndroidYada.scheduleReminder(title,scheduledDate.getTime(),isBirthday,!!item.monthlyRepeat);
  if(!window.AndroidYada.hasNotificationPermission())alert('یادآوری زمان‌بندی شد، اما مجوز نمایش اعلان خاموش است. از تنظیمات اعلان‌های یادا را فعال کن؛ می‌توانی از زبانه «صدا» وضعیت را بررسی کنی.');
  else if(!exact&&await themedConfirm('یادآوری ثبت شد، اما دسترسی هشدار دقیق فعال نیست و ممکن است اعلان با تأخیر برسد. اکنون دسترسی هشدار دقیق را فعال می‌کنی؟'))window.AndroidYada.requestExactAlarmPermission();
 }
 data[currentView].push(item);
 save();closeModal();
 if(document.getElementById('months').classList.contains('active')){currentView=currentMonthType;renderMonths()}
}
async function removeItem(type,id){
 if(!await themedConfirm('این مورد حذف شود؟'))return;
 const item=data[type].find(x=>x.id===id);
 if(item&&item.reminderAt&&window.AndroidYada&&AndroidYada.cancelReminder)AndroidYada.cancelReminder(item.title,item.reminderAt);
 data[type]=data[type].filter(x=>x.id!==id);save();
 if(document.getElementById('monthDetailView').style.display==='block')renderMonthDetail();
}function toggleTask(id){let x=data.tasks.find(x=>x.id===id);if(x)x.done=!x.done;save()}
function isExpiredEvent(x,type){if(type==='birthdays'||!x.date)return false;const t=new Date(x.date+'T'+(x.time||'23:59')+':00').getTime();return Number.isFinite(t)&&t<Date.now()}
function card(type,x){let extra=type==='payments'&&x.amount?`<span class="amount">${fa(Number(x.amount))} تومان</span>`:'';let date=x.date?fmt(x.date):'تاریخ ثبت نشده';let time=x.time?' · '+formatClock(x.time):'';let checked=type==='tasks'?`<input type="checkbox" ${x.done?'checked':''} onchange="toggleTask(${x.id})">`:'';let expired=isExpiredEvent(x,type);return `<div class="event${expired?' expired':''}${type==='tasks'&&x.done?' completed-task':''}">${checked}<div class="eventicon">${icons[type]}</div><div class="eventmain"><b>${escapeHtml(x.title)}</b><small>${date}${time}</small>${type==='tasks'&&x.done&&x.note?`<small class="task-detail">جزئیات: ${escapeHtml(x.note)}</small>`:x.note?`<small>${escapeHtml(x.note)}</small>`:''}</div>${expired?'<span class="expired-label">منقضی</span>':''}${extra}<button class="delete" aria-label="حذف رویداد" onclick="removeItem('${type}',${x.id})">×</button></div>`}
function upcomingKey(x){return `${x.type}:${x.id}:${x.date||''}:${x.time||''}`}
function dismissUpcoming(type,id,date,time){let list=[];try{list=JSON.parse(localStorage.getItem('yadaDismissedUpcoming')||'[]')}catch(e){}const key=upcomingKey({type,id,date,time});if(!list.includes(key))list.push(key);localStorage.setItem('yadaDismissedUpcoming',JSON.stringify(list));render()}
function upcomingCard(x){return `<div class="event"><div class="eventicon">${icons[x.type]||'📅'}</div><div class="eventmain"><b>${escapeHtml(x.title)}</b><small>${fmt(x.date)}${x.time?' · '+formatClock(x.time):''}${x.note?' · '+escapeHtml(x.note):''}</small></div><button class="delete" aria-label="بستن نمایش یادآوری؛ رویداد حذف نمی‌شود" title="بستن یادآوری، بدون حذف رویداد" onclick="dismissUpcoming('${x.type}',${x.id},'${x.date||''}','${x.time||''}')">×</button></div>`}
// پس از تحویل اعلان، رویداد یک‌باره دیگر به‌عنوان نزدیک‌ترین رویداد برنمی‌گردد.
// برای تولدهای سالانه و پرداخت‌های ماهانه، نوبت بعدی یادآوری محاسبه می‌شود.
function upcomingReminderPending(x,nowMs){
 const base=Number(x.reminderAt)||0;
 if(!base)return true;
 const firedAt=t=>!!(window.AndroidYada&&AndroidYada.wasReminderFired&&AndroidYada.wasReminderFired(x.title,t));
 if(!firedAt(base))return true;
 if(x.type==='birthdays'){
  const next=new Date(base);
  while(next.getTime()<=nowMs)next.setFullYear(next.getFullYear()+1);
  return !firedAt(next.getTime());
 }
 if(x.type==='payments'&&x.monthlyRepeat){
  const next=new Date(base);
  while(next.getTime()<=nowMs)next.setMonth(next.getMonth()+1);
  return !firedAt(next.getTime());
 }
 return false;
}
function escapeHtml(s){return String(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}

const jalaliMonths=['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'];
function jalaliMonthOf(iso){if(!iso)return 0;try{return jalaliParts(new Date(iso+'T12:00:00')).month||0}catch(e){return 0}}
function monthEventIsRelevant(item,type,month){if(!item.date||jalaliMonthOf(item.date)!==month)return false;/* کارها تاریخچه‌اند: چه انجام‌شده چه عقب‌افتاده، از ماه حذف نمی‌شوند. */if(type==='tasks')return true;return !isExpiredEvent(item,type);}
function monthItems(month){
 return Object.keys(data).flatMap(type=>(data[type]||[]).filter(item=>monthEventIsRelevant(item,type,month)).map(item=>({...item,type}))).sort((a,b)=>{const byCreated=Number(b.id||0)-Number(a.id||0);return byCreated||((b.date||'').localeCompare(a.date||''))||((b.time||'').localeCompare(a.time||''));});
}
function openMonth(month){selectedMonth=month;monthPage=0;document.getElementById('monthPickerView').style.display='none';document.getElementById('monthDetailView').style.display='block';renderMonthDetail()}
function backToMonths(){selectedMonth=null;document.getElementById('monthPickerView').style.display='block';document.getElementById('monthDetailView').style.display='none';renderMonths()}
function shiftMonthPage(delta){monthPage=Math.max(0,monthPage+delta);renderMonthDetail()}
function showSettingsTab(name,btn){document.querySelectorAll('.settings-tabs button').forEach(x=>x.classList.remove('active'));document.querySelectorAll('.settings-panel').forEach(x=>x.classList.remove('active'));if(btn)btn.classList.add('active');document.getElementById('settings-'+name).classList.add('active')}
function renderMonths(){
 const grid=document.getElementById('monthGrid');if(!grid)return;
 const type=currentMonthType, titleMap={birthdays:'🎂 تولدها و سالگردها',appointments:'📅 قرارها و یادآوری‌ها',tasks:'✓ کارهای روزانه',payments:'💳 پرداخت‌ها و اقساط'};
 const eventEmoji=type==='birthdays'?'🎂':type==='appointments'?'📅':type==='tasks'?'✓':'💳';
 const monthSymbols=Array.from({length:12},(_,i)=>`month-symbol-${String(i+1).padStart(2,'0')}.png`);
 document.getElementById('monthsHeading').textContent='رویدادهای مهم';
 document.getElementById('monthAddTop')?.remove();
 document.getElementById('monthAddDetail').style.display='none';
 document.getElementById('monthLegend').textContent='تعداد رویدادهای آینده در هر ماه · شامل همه دسته‌ها';
 const nowParts=jalaliParts(new Date()),thisMonth=nowParts.month;
 grid.innerHTML=jalaliMonths.map((name,i)=>{
  const m=i+1,items=Object.keys(data).flatMap(k=>(data[k]||[]).filter(x=>monthEventIsRelevant(x,k,m))),count=items.length;
  const done=type==='tasks'?items.filter(x=>x.done).length:0;
  const countLabel=`${fa(count)} مورد`;
  return `<button class="month-card${m===thisMonth?' current-month':''}" type="button" onclick="openMonth(${m})" aria-label="${name}، ${fa(count)} مورد ثبت‌شده">
   <span class="month-card-top"><b class="month-name">${name}</b><img class="month-symbol-img" src="${monthSymbols[i]}" alt="" aria-hidden="true"></span>
   <span class="month-card-bottom"><span class="month-count">${fa(count)} مورد</span></span>
  </button>`;
 }).join('');
 if(selectedMonth!==null){document.getElementById('monthPickerView').style.display='none';document.getElementById('monthDetailView').style.display='block';renderMonthDetail()}else{document.getElementById('monthPickerView').style.display='block';document.getElementById('monthDetailView').style.display='none'}
}
function renderMonthDetail(){
 if(selectedMonth===null)return;
 const items=monthItems(selectedMonth),pageSize=5,pages=Math.max(1,Math.ceil(items.length/pageSize));monthPage=Math.min(monthPage,pages-1);
 document.getElementById('monthDetailTitle').textContent=jalaliMonths[selectedMonth-1]+' · '+fa(items.length)+' مورد';
 const shown=items.slice(monthPage*pageSize,monthPage*pageSize+pageSize);
 document.getElementById('monthItems').innerHTML=shown.length?shown.map(x=>{let d=fmt(x.date),time=x.time?' · '+formatClock(x.time):'',icon=icons[x.type]||'✓',label=labels[x.type]||'کار';let expired=isExpiredEvent(x,x.type),isTask=x.type==='tasks',doneTask=isTask&&x.done===true;return `<div class="event${expired?' expired':''}${isTask?' month-task-card':''}${doneTask?' completed-task':''}">${isTask?`<input type="checkbox" ${x.done?'checked':''} aria-label="وضعیت انجام کار" onchange="toggleTask(${x.id});renderMonthDetail();render()">`:''}<div class="eventicon">${icon}</div><div class="eventmain"><b>${escapeHtml(x.title)}</b><small>تاریخ: ${d}${time}</small><small>دسته‌بندی: ${label}</small>${x.note?`<small class="task-detail">${doneTask?'جزئیات کار انجام‌شده: ':'توضیحات کامل: '}${escapeHtml(x.note)}</small>`:'<small class="task-detail">توضیحات: ثبت نشده</small>'}</div>${doneTask?'<span class="done-label">انجام‌شده</span>':''}${expired?'<span class="expired-label">تاریخ گذشته</span>':''}${x.type==='payments'&&x.amount?`<span class="amount">${fa(Number(x.amount))} تومان</span>`:''}<button class="delete" aria-label="حذف مورد" onclick="removeItem('${x.type}',${x.id}).then(()=>renderMonthDetail())">×</button></div>`}).join(''):'<div class="empty">برای این ماه موردی در بخش '+titleMapSafe(currentMonthType)+' ثبت نشده.</div>';
 document.getElementById('monthPageLabel').textContent=fa(monthPage+1)+' / '+fa(pages);
 document.getElementById('monthPrev').disabled=monthPage===0;document.getElementById('monthNext').disabled=monthPage>=pages-1;
}
function titleMapSafe(type){return ({birthdays:'تولد',appointments:'قرار',tasks:'کار',payments:'پرداخت'})[type]||'مورد'}

function render(){
 for(let t of Object.keys(data)){let el=document.getElementById(t+'List');if(el)el.innerHTML=data[t].length?data[t].slice().sort((a,b)=>(a.date||'9999').localeCompare(b.date||'9999')).map(x=>card(t,x)).join(''):'<div class="empty">هنوز موردی ثبت نکردی.<br>از دکمه «افزودن» شروع کن.</div>'}
 document.getElementById('todoCount').textContent=fa(data.tasks.filter(x=>!x.done&&!isExpiredEvent(x,'tasks')).length);
 document.getElementById('eventCount').textContent=fa(Object.keys(data).reduce((n,type)=>n+data[type].filter(x=>!isExpiredEvent(x,type)&&!(type==='tasks'&&x.done)).length,0));
 document.getElementById('payCount').textContent=fa(data.payments.length);
 const now=new Date();now.setSeconds(0,0);
 const upcoming=Object.keys(data).flatMap(type=>(data[type]||[]).map(x=>({...x,type}))).filter(x=>x.date&&!isExpiredEvent(x,x.type)&&!(x.type==='tasks'&&x.done)&&x.done!==true).map(x=>{
  const source=new Date(x.date+'T12:00:00');if(Number.isNaN(source.getTime()))return null;let d=new Date(source);
  if(x.type==='birthdays'){d.setFullYear(now.getFullYear());const tm=x.time||'09:00';d.setHours(Number(tm.slice(0,2)),Number(tm.slice(3,5)),0,0);if(d<now){d.setFullYear(now.getFullYear()+1)}}else{const tm=x.time||'23:59';d=new Date(x.date+'T'+tm+':00')}
  const displayDate=x.type==='birthdays'?`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`:x.date;
  return {...x,date:displayDate,_next:d};
 }).filter(x=>{if(!x)return false;const nowMs=Date.now();const eventFuture=x._next instanceof Date&&!Number.isNaN(x._next.getTime())&&x._next.getTime()>nowMs;const reminderStillPending=upcomingReminderPending(x,nowMs);let dismissed=[];try{dismissed=JSON.parse(localStorage.getItem('yadaDismissedUpcoming')||'[]')}catch(e){}const notDismissed=!dismissed.includes(upcomingKey(x));return !isExpiredEvent(x,x.type)&&eventFuture&&reminderStillPending&&notDismissed;}).sort((a,b)=>a._next-b._next);
 const next=upcoming[0];
 document.getElementById('upcoming').innerHTML=next?upcomingCard(next):'';
 renderMonths();
}



// مدیریت مالی یادا؛ داده‌ها مستقل از یادآوری‌ها و به‌صورت محلی نگهداری می‌شوند.
function saveFinance(){localStorage.setItem('yadaFinance',JSON.stringify(financeData));renderFinance()}
function jalaliToday(){let p=jalaliParts(new Date());return `${p.year}/${String(p.month).padStart(2,'0')}/${String(p.day).padStart(2,'0')}`}
let editingTransactionId=null,editingDebtId=null;
function openFinanceForm(type,id=null){const item=id!=null?financeData.transactions.find(x=>String(x.id)===String(id)):null;financeType=item?.type||type;editingTransactionId=item?item.id:null;document.getElementById('financeModalTitle').textContent=item?(financeType==='income'?'ویرایش درآمد':'ویرایش هزینه'):(financeType==='income'?'ثبت درآمد':'ثبت هزینه');document.getElementById('financeTitle').value=item?.title||'';document.getElementById('financeAmount').value=item?new Intl.NumberFormat('fa-IR',{maximumFractionDigits:0}).format(item.amount):'';document.getElementById('financeCategory').value=item?.category||(financeType==='income'?'حقوق و درآمد':'خرید و سوپرمارکت');document.getElementById('financeDate').value=item?.date?toJalaliInput(item.date).replaceAll('-','/'):jalaliToday();document.getElementById('financeNote').value=item?.note||'';document.getElementById('financeModal').style.display='flex'}
function closeFinanceModal(){document.getElementById('financeModal').style.display='none'}
function saveFinanceTransaction(){let title=document.getElementById('financeTitle').value.trim(),amount=normalizeFinanceAmount(document.getElementById('financeAmount').value),dateText=document.getElementById('financeDate').value.trim(),date=parseJalali(dateText);if(!title||!Number.isFinite(amount)||amount<=0){alert('عنوان و مبلغ معتبر را وارد کن.');return}if(!date){alert('تاریخ شمسی را به شکل سال/ماه/روز وارد کن.');return}const item={title,amount,category:document.getElementById('financeCategory').value,date,note:document.getElementById('financeNote').value.trim(),type:financeType};if(editingTransactionId!==null){const index=financeData.transactions.findIndex(x=>String(x.id)===String(editingTransactionId));if(index>=0)financeData.transactions[index]={...financeData.transactions[index],...item,id:financeData.transactions[index].id};else financeData.transactions.push({id:Date.now(),...item})}else financeData.transactions.push({id:Date.now(),...item});editingTransactionId=null;closeFinanceModal();saveFinance()}
function openDebtForm(id=null){editingDebtId=id;const d=id?financeData.debts.find(x=>x.id===id):null;['debtPerson','debtAmount','debtNote','debtDue'].forEach(k=>document.getElementById(k).value='');document.getElementById('debtKind').value=d?.kind||'owed';document.getElementById('debtPerson').value=d?.person||'';document.getElementById('debtAmount').value=d?new Intl.NumberFormat('fa-IR',{maximumFractionDigits:0}).format(d.amount):'';document.getElementById('debtNote').value=d?.note||'';document.getElementById('debtDue').value=d?.due?(String(d.due).includes('-')?toJalaliInput(d.due):d.due):'';document.querySelector('#debtModal h3').textContent=d?'ویرایش بدهی یا طلب':'ثبت بدهی یا طلب';document.getElementById('debtModal').style.display='flex'}
function closeDebtModal(){document.getElementById('debtModal').style.display='none'}
function saveDebt(){let person=document.getElementById('debtPerson').value.trim(),amount=normalizeFinanceAmount(document.getElementById('debtAmount').value),dueText=document.getElementById('debtDue').value.trim(),due=dueText?parseJalali(dueText):'';if(!person||!Number.isFinite(amount)||amount<=0){alert('نام شخص و مبلغ معتبر را وارد کن.');return}if(dueText&&!due){alert('تاریخ سررسید معتبر نیست.');return}const item={kind:document.getElementById('debtKind').value,person,amount,note:document.getElementById('debtNote').value.trim(),due};if(editingDebtId){const old=financeData.debts.find(x=>x.id===editingDebtId);if(old)Object.assign(old,item)}else financeData.debts.push({id:Date.now(),...item,paid:false});editingDebtId=null;closeDebtModal();saveFinance()}
function settleDebt(id){let d=financeData.debts.find(x=>x.id===id);if(d)d.paid=!d.paid;saveFinance()}
async function deleteFinanceItem(kind,id){if(!await themedConfirm('این مورد حذف شود؟'))return;if(kind==='transaction')financeData.transactions=financeData.transactions.filter(x=>x.id!==id);else financeData.debts=financeData.debts.filter(x=>x.id!==id);saveFinance()}
let budgetEditMode='monthly';
function openBudgetModal(mode){budgetEditMode=mode;const categoryField=document.getElementById('budgetCategoryField');categoryField.style.display=mode==='category'?'grid':'none';document.getElementById('budgetModalTitle').textContent=mode==='category'?'تنظیم بودجه دسته‌بندی':'تنظیم بودجه ماهانه';document.getElementById('budgetAmountInput').value='';if(mode==='category'){const name=document.getElementById('budgetCategory').value;document.getElementById('budgetAmountInput').value=financeData.categoryBudgets[name]?new Intl.NumberFormat('fa-IR',{maximumFractionDigits:0}).format(financeData.categoryBudgets[name]):'';}else{document.getElementById('budgetAmountInput').value=financeData.monthlyBudget?new Intl.NumberFormat('fa-IR',{maximumFractionDigits:0}).format(financeData.monthlyBudget):'';}document.getElementById('budgetModal').style.display='flex'}
function closeBudgetModal(){document.getElementById('budgetModal').style.display='none'}
function saveBudgetEdit(){const n=normalizeFinanceAmount(document.getElementById('budgetAmountInput').value);if(!n){alert('مبلغ معتبر و بزرگ‌تر از صفر وارد کن.');return}if(budgetEditMode==='category'){const name=document.getElementById('budgetCategory').value;financeData.categoryBudgets[name]=n;}else{financeData.monthlyBudget=n;}closeBudgetModal();saveFinance()}
function editCategoryBudget(){openBudgetModal('category')}
function editMonthlyBudget(){openBudgetModal('monthly')}
function editCategoryBudgetNamed(button){document.getElementById('budgetCategory').value=button.dataset.category;openBudgetModal('category')}
async function deleteCategoryBudget(name){if(!await themedConfirm('بودجه این دسته‌بندی حذف شود؟'))return;delete financeData.categoryBudgets[name];saveFinance()}
async function deleteMonthlyBudget(){if(!await themedConfirm('بودجه ماهانه حذف شود؟'))return;financeData.monthlyBudget=0;saveFinance()}
function showFinanceTab(name,btn){document.querySelectorAll('.finance-tabs button').forEach(x=>x.classList.remove('active'));document.querySelectorAll('.finance-panel[id^="finance-"]').forEach(x=>x.classList.remove('active'));let b=btn||[...document.querySelectorAll('.finance-tabs button')].find(x=>x.getAttribute('onclick')?.includes("'"+name+"'"));if(b)b.classList.add('active');document.getElementById('finance-'+name)?.classList.add('active');}

function renderFinanceChart(transactions,now){
 const host=document.getElementById('financeChart');if(!host)return;
 const months=[];let year=now.year,month=now.month;
 for(let i=0;i<6;i++){months.unshift({year,month});month--;if(month<1){month=12;year--;}}
 const rows=months.map(m=>{
  let inc=0,exp=0;
  transactions.forEach(x=>{
   const amount=normalizeFinanceAmount(x.amount);
   if(!x.date)return;
   const p=jalaliParts(new Date(x.date+'T12:00:00'));
   if(p.year===m.year&&p.month===m.month){if(x.type==='income')inc+=amount;else if(x.type==='expense')exp+=amount;}
  });
  return {...m,inc,exp};
 });
 const max=Math.max(1,...rows.flatMap(x=>[x.inc,x.exp]));
 host.innerHTML=rows.map(r=>{
  const ih=r.inc?Math.max(4,Math.round(r.inc/max*100)):2;
  const eh=r.exp?Math.max(4,Math.round(r.exp/max*100)):2;
  return `<div class="chart-month" aria-label="${jalaliMonths[r.month-1]}: درآمد ${fa(r.inc)}، هزینه ${fa(r.exp)}">
   <div class="chart-bars"><span class="chart-bar income-bar" style="height:${ih}%" title="درآمد: ${fa(r.inc)}"></span><span class="chart-bar expense-bar" style="height:${eh}%" title="هزینه: ${fa(r.exp)}"></span></div>
   <small>${jalaliMonths[r.month-1].slice(0,3)}</small>
  </div>`;
 }).join('');
}
function searchFinanceTransactions(){
 const ft=document.getElementById('financeSearchFrom').value.trim(),tt=document.getElementById('financeSearchTo').value.trim(),from=ft?parseJalali(ft):'',to=tt?parseJalali(tt):'';
 if(ft&&!from||tt&&!to){alert('تاریخ جست‌وجو معتبر نیست.');return}if(from&&to&&from>to){alert('تاریخ شروع نباید بعد از پایان باشد.');return}
 const type=document.getElementById('financeSearchType').value,q=document.getElementById('financeSearchText').value.trim().toLocaleLowerCase('fa'),inRange=d=>(!from||!!d&&d>=from)&&(!to||!!d&&d<=to),matches=x=>!q||[x.title,x.category,x.note,x.person].join(' ').toLocaleLowerCase('fa').includes(q);
 let rows=[];if(type==='all'||type==='income'||type==='expense')rows.push(...financeData.transactions.filter(x=>inRange(x.date)&&(type==='all'||x.type===type)&&matches(x)).map(x=>({...x,kind:x.type,sortDate:x.date})));
 if(type==='all'||type==='owed'||type==='receivable')rows.push(...financeData.debts.filter(x=>inRange(x.due)&&(type==='all'||x.kind===type)&&matches(x)).map(x=>({...x,title:x.person,category:x.kind==='owed'?'بدهی':'طلب',kind:x.kind,sortDate:x.due})));
 rows.sort((a,b)=>String(b.sortDate||'').localeCompare(String(a.sortDate||'')));const inc=rows.filter(x=>x.kind==='income'||x.kind==='receivable').reduce((n,x)=>n+normalizeFinanceAmount(x.amount),0),out=rows.filter(x=>x.kind==='expense'||x.kind==='owed').reduce((n,x)=>n+normalizeFinanceAmount(x.amount),0),fm=formatFinanceMoney;
 document.getElementById('financeSearchSummary').innerHTML=`<div><b>${fa(rows.length)}</b><small>مورد پیدا شد</small></div><div><b class="positive">${fm(inc)}</b><small>درآمد و طلب</small></div><div><b class="negative">${fm(out)}</b><small>هزینه و بدهی</small></div>`;
 document.getElementById('financeSearchResults').innerHTML=rows.length?rows.map(x=>`<div class="finance-row"><div class="eventicon">${x.kind==='income'||x.kind==='receivable'?'↗':'↘'}</div><div class="eventmain"><b>${escapeHtml(x.title)}</b><small>${escapeHtml(x.category||'بدون دسته')} · ${x.sortDate?fmt(x.sortDate):'بدون تاریخ'}</small></div><span class="finance-value ${x.kind==='income'||x.kind==='receivable'?'positive':'negative'}">${x.kind==='income'||x.kind==='receivable'?'+':'−'}${fm(x.amount)}</span></div>`).join(''):'<div class="empty">موردی پیدا نشد.</div>';
}

const financeLimits={expense:20,income:20,debt:20};function moreFinance(kind){financeLimits[kind]+=20;renderFinance()}function pagedFinance(kind,items,html){let n=financeLimits[kind],out=items.slice(0,n).map(html).join('');return out+(items.length>n?`<button class=\"finance-more\" onclick=\"moreFinance('\\${kind}')\">نمایش موارد بیشتر (${fa(items.length-n)} باقی‌مانده)</button>`:'')}
function renderFinance(){if(!document.getElementById('finance'))return;let now=jalaliParts(new Date()),monthTx=financeData.transactions.filter(x=>{if(!/^\d{4}-\d{2}-\d{2}$/.test(String(x.date||'')))return false;let p=jalaliParts(new Date(x.date+'T12:00:00'));return p.year===now.year&&p.month===now.month}),income=monthTx.filter(x=>x.type==='income').reduce((a,x)=>a+normalizeFinanceAmount(x.amount),0),expense=monthTx.filter(x=>x.type==='expense').reduce((a,x)=>a+normalizeFinanceAmount(x.amount),0),fmtMoney=formatFinanceMoney;document.getElementById('financeMonthLabel').textContent=jalaliMonths[now.month-1]+' '+fa(now.year);document.getElementById('financeIncome').textContent=fmtMoney(income);document.getElementById('financeExpense').textContent=fmtMoney(expense);document.getElementById('financeBalance').textContent=fmtMoney(income-expense);
 let recent=financeData.transactions.slice().sort((a,b)=>b.id-a.id).slice(0,5);document.getElementById('financeRecent').innerHTML=recent.length?recent.map(x=>`<div class="finance-row"><div class="eventicon">${x.type==='income'?'↗':'↘'}</div><div class="eventmain"><b>${escapeHtml(x.title)}</b><small>${escapeHtml(x.category)} · ${fmt(x.date)}</small></div><span class="finance-value ${x.type==='income'?'positive':'negative'}">${x.type==='income'?'+':'−'}${fmtMoney(x.amount)}</span></div>`).join(''):'<div class="empty">هنوز تراکنش مالی ثبت نشده است.</div>';
 let allExpenses=financeData.transactions.filter(x=>x.type==='expense').slice().sort((a,b)=>b.id-a.id);document.getElementById('financeExpenseDetails').innerHTML=allExpenses.length?allExpenses.slice(0,financeLimits.expense).map(x=>`<div class="finance-row expense-detail-row"><div class="eventicon">↘</div><div class="eventmain"><b>${escapeHtml(x.title)}</b><small>${escapeHtml(x.category)} · ${fmt(x.date)}${x.note?' · '+escapeHtml(x.note):''}</small></div><span class="finance-value negative">−${fmtMoney(x.amount)}</span><button class="secondary" style="padding:6px" onclick="openFinanceForm('expense',${x.id})">ویرایش</button><button class="delete" aria-label="حذف هزینه" onclick="deleteFinanceItem('transaction',${x.id})">×</button></div>`).join('')+(allExpenses.length>financeLimits.expense?`<button class="finance-more" onclick="moreFinance('expense')">نمایش موارد بیشتر</button>`:''):'<div class="empty">هنوز هزینه‌ای ثبت نشده است.</div>';
 let allIncomes=financeData.transactions.filter(x=>x.type==='income').slice().sort((a,b)=>b.id-a.id);document.getElementById('financeIncomeDetails').innerHTML=allIncomes.length?allIncomes.slice(0,financeLimits.income).map(x=>`<div class="finance-row expense-detail-row"><div class="eventicon">↗</div><div class="eventmain"><b>${escapeHtml(x.title)}</b><small>${escapeHtml(x.category)} · ${fmt(x.date)}${x.note?' · '+escapeHtml(x.note):''}</small></div><span class="finance-value positive">+${fmtMoney(x.amount)}</span><button class="secondary" style="padding:6px" onclick="openFinanceForm('income',${x.id})">ویرایش</button><button class="delete" aria-label="حذف درآمد" onclick="deleteFinanceItem('transaction',${x.id})">×</button></div>`).join('')+(allIncomes.length>financeLimits.income?`<button class="finance-more" onclick="moreFinance('income')">نمایش موارد بیشتر</button>`:''):'<div class="empty">هنوز درآمدی ثبت نشده است.</div>';
 let cats={};monthTx.filter(x=>x.type==='expense').forEach(x=>cats[x.category]=(cats[x.category]||0)+normalizeFinanceAmount(x.amount));let entries=Object.entries(cats).sort((a,b)=>b[1]-a[1]);document.getElementById('financeCategories').innerHTML=entries.length?entries.map(([n,v])=>`<div style="margin:9px 0"><div style="display:flex;justify-content:space-between;font-size:11px"><span>${escapeHtml(n)}</span><b>${fmtMoney(v)}</b></div><div class="finance-progress"><span style="width:${expense?Math.min(100,v/expense*100):0}%"></span></div></div>`).join(''):'<div class="empty">پس از ثبت هزینه، گزارش دسته‌بندی اینجا نمایش داده می‌شود.</div>';
 let debts=financeData.debts.filter(x=>!x.paid),owed=debts.filter(x=>x.kind==='owed').reduce((a,x)=>a+x.amount,0),receivable=debts.filter(x=>x.kind==='receivable').reduce((a,x)=>a+x.amount,0);document.getElementById('debtTotal').textContent=fmtMoney(owed);document.getElementById('receivableTotal').textContent=fmtMoney(receivable);document.getElementById('debtList').innerHTML=financeData.debts.length?financeData.debts.slice().sort((a,b)=>b.id-a.id).slice(0,financeLimits.debt).map(x=>`<div class="finance-row debt-row"><div class="debt-primary"><div class="eventicon">${x.kind==='owed'?'↘':'↗'}</div><div class="eventmain"><b>${escapeHtml(x.person||'شخص ثبت‌نشده')} · ${x.kind==='owed'?'بدهی':'طلب'}</b><small>${x.due?'سررسید: '+fmt(x.due):'بدون سررسید'}${x.note?' · '+escapeHtml(x.note):''}${x.paid?' · تسویه‌شده':''}</small></div><span class="finance-value ${x.kind==='owed'?'negative':'positive'}">${fmtMoney(x.amount)}</span></div><div class="debt-actions"><button class="secondary" onclick="openDebtForm(${x.id})">ویرایش جزئیات</button><button class="secondary debt-settle-btn ${x.paid?'settled-btn':''}" onclick="settleDebt(${x.id})">${x.paid?'بازگرداندن تسویه':'ثبت تسویه'}</button><button class="delete" aria-label="حذف بدهی یا طلب" onclick="deleteFinanceItem('debt',${x.id})">×</button></div></div>`).join('')+(financeData.debts.length>financeLimits.debt?`<button class="finance-more" onclick="moreFinance('debt')">نمایش موارد بیشتر</button>`:''):'<div class="empty">هنوز بدهی یا طلبی ثبت نشده است.</div>';
 let spent=expense,budget=Number(financeData.monthlyBudget)||0,percent=budget?Math.min(100,spent/budget*100):0;document.getElementById('budgetAmount').textContent=budget?fmtMoney(budget):'تعیین نشده';document.getElementById('budgetSpent').textContent='هزینه این ماه: '+fmtMoney(spent);document.getElementById('budgetProgress').style.width=percent+'%';document.getElementById('budgetRemaining').textContent=budget?(spent>budget?'از بودجه ماهانه عبور کرده‌ای: '+fmtMoney(spent-budget):'مانده بودجه: '+fmtMoney(budget-spent)):'برای شروع، بودجه ماهانه را تعیین کن.';let budgetCats=Object.entries(financeData.categoryBudgets||{});document.getElementById('categoryBudgets').innerHTML=budgetCats.length?budgetCats.map(([n,cap])=>{let used=cats[n]||0,p=cap?Math.min(100,used/cap*100):0;return `<div style="margin:10px 0"><div style="display:flex;justify-content:space-between;align-items:center;gap:6px;font-size:11px"><b>${escapeHtml(n)}</b><span>${fmtMoney(used)} / ${fmtMoney(cap)}</span><button class="secondary" style="padding:4px 7px" onclick="editCategoryBudgetNamed(this)" data-category="${escapeHtml(n)}">ویرایش</button><button class="delete" onclick="deleteCategoryBudget(this.dataset.category)" data-category="${escapeHtml(n)}">×</button></div><div class="finance-progress"><span style="width:${p}%"></span></div></div>`}).join('') :'<div class="empty">برای دسته‌های دلخواه سقف هزینه تعیین کن.</div>';
 renderFinanceChart(financeData.transactions,now);
}

// قفل ورود با کد عددی و اثر انگشت
const PIN_KEY='yadaPinHash';
let gateMode='';
async function secureHash(value){
  const bytes=new TextEncoder().encode(String(value));
  const digest=await crypto.subtle.digest('SHA-256',bytes);
  return [...new Uint8Array(digest)].map(x=>x.toString(16).padStart(2,'0')).join('');
}
function gateError(msg){document.getElementById('gateError').textContent=msg||''}
function gateFields(markup){document.getElementById('gateFields').innerHTML=markup}
function pinInput(id,label){return `<input id="${id}" type="password" inputmode="numeric" maxlength="8" placeholder="${label}" autocomplete="off">`}
function showGate(){
 document.body.classList.add('gated');
 const first=!localStorage.getItem(PIN_KEY);
 document.getElementById('gateTitle').textContent=first?'ساخت رمز ورود':'قفل یادا';
 document.getElementById('gateText').textContent=first?'یک رمز عددی ۴ تا ۸ رقمی بساز.':'برای ورود، کد خود را وارد کن یا از اثر انگشت استفاده کن.';
 gateMode=first?'setup':'unlock';
 gateFields(pinInput('gatePin',first?'رمز جدید':'کد ورود')+(first?pinInput('gatePin2','تکرار رمز'):''));
 document.getElementById('gateMain').textContent=first?'ساخت رمز':'ورود با کد';
 document.getElementById('gateBiometric').style.display=(!first && window.AndroidYada && AndroidYada.biometricAvailable())?'block':'none';
}
function validPin(v){return /^\d{4,8}$/.test(v||'')}
async function gateSubmit(){
 gateError('');
 if(gateMode==='setup'){
  const p=document.getElementById('gatePin').value,p2=document.getElementById('gatePin2').value;
  if(!validPin(p)){gateError('رمز باید ۴ تا ۸ رقم باشد.');return}
  if(p!==p2){gateError('دو رمز با هم یکسان نیستند.');return}
  localStorage.setItem(PIN_KEY,await secureHash(p));
  unlockYada();return;
 }
 if(gateMode==='unlock'){
  const p=document.getElementById('gatePin').value;
  if(await secureHash(p)!==localStorage.getItem(PIN_KEY)){gateError('کد ورود اشتباه است.');return}
  unlockYada();
 }
}
function startBiometric(){
 if(window.AndroidYada && AndroidYada.biometricAvailable()) AndroidYada.authenticateBiometric();
 else gateError('اثر انگشت روی این گوشی در دسترس نیست؛ با کد وارد شو.');
}
window.onBiometricResult=function(ok){if(ok)unlockYada();else gateError('ورود با اثر انگشت انجام نشد؛ دوباره تلاش کن یا با کد وارد شو.')};
function unlockYada(){document.body.classList.remove('gated');document.getElementById('yadaGate').style.display='none';}
showGate();


// تقویم انتخابی شمسی؛ تاریخ ذخیره‌شده همچنان به‌صورت میلادی استاندارد نگهداری می‌شود.
let calYear=Number(new Intl.DateTimeFormat('en-u-ca-persian-nu-latn',{year:'numeric'}).format(new Date())),calMonth=Number(new Intl.DateTimeFormat('en-u-ca-persian-nu-latn',{month:'numeric'}).format(new Date()));let selectedCalendarIso='',selectedCalendarTarget='dateInput';
function jalaliParts(d){let a=new Intl.DateTimeFormat('en-u-ca-persian-nu-latn',{year:'numeric',month:'numeric',day:'numeric'}).formatToParts(d),o={};a.forEach(x=>o[x.type]=Number(x.value));return o}
function openJalaliCalendar(){openJalaliCalendarFor('dateInput')}
function openJalaliCalendarFor(targetId){selectedCalendarTarget=targetId;let field=document.getElementById(targetId),v=field?.value||'';let m=v.match(/(\d{4})[\/\-.](\d{1,2})[\/\-.](\d{1,2})/);selectedCalendarIso=m?parseJalali(v):'';if(m){calYear=+m[1];calMonth=+m[2]}else{let p=new Intl.DateTimeFormat('en-u-ca-persian-nu-latn',{year:'numeric',month:'numeric'}).formatToParts(new Date());let o={};p.forEach(x=>o[x.type]=x.value);calYear=+o.year;calMonth=+o.month}renderJalaliCalendar();document.getElementById('calendarModal').style.display='flex'}
function closeCalendar(){document.getElementById('calendarModal').style.display='none'}
function shiftJalaliMonth(n){calMonth+=n;if(calMonth>12){calMonth=1;calYear++}if(calMonth<1){calMonth=12;calYear--}renderJalaliCalendar()}
function renderJalaliCalendar(){
 let months=['فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'];
 document.getElementById('calendarTitle').innerHTML=`<span class="calendar-title-year">${toFaDigits(calYear)}</span><span class="calendar-title-month">${months[calMonth-1]}</span>`;
 let ms=document.getElementById('calendarMonth'),ys=document.getElementById('calendarYear');
 if(!ms.options.length)ms.innerHTML=months.map((x,i)=>`<option value="${i+1}">${x}</option>`).join('');
 if(!ys.options.length){let now=calYear;ys.innerHTML=Array.from({length:181},(_,i)=>now-90+i).map(y=>`<option value="${y}">${toFaDigits(y)}</option>`).join('')}
 if(![...ys.options].some(o=>+o.value===calYear))ys.innerHTML+=`<option value="${calYear}">${toFaDigits(calYear)}</option>`;
 ms.value=String(calMonth);ys.value=String(calYear);
 let grid=document.getElementById('calendarGrid'),names=['ش','ی','د','س','چ','پ','ج'];
 grid.innerHTML=names.map(x=>`<b class="calendar-weekday">${x}</b>`).join('');
 let first=new Date(jalaliToGregorian(calYear,calMonth,1)+'T12:00:00'),weekday=(first.getDay()+1)%7;
 for(let i=0;i<weekday;i++)grid.innerHTML+='<span></span>';
 let yearStart=new Date(jalaliToGregorian(calYear,1,1)+'T12:00:00'),nextYear=new Date(jalaliToGregorian(calYear+1,1,1)+'T12:00:00');
 let max=calMonth<=6?31:calMonth<=11?30:((nextYear-yearStart)/86400000===366?30:29);
 for(let day=1;day<=max;day++){
  let g=jalaliToGregorian(calYear,calMonth,day),isSelected=g===selectedCalendarIso;
  grid.innerHTML+=`<button class="calendar-day${isSelected?' selected':''}" type="button" onclick="selectJalaliDate('${g}')">${fa(day)}</button>`;
 }
}
function selectJalaliDate(iso){selectedCalendarIso=iso;const target=document.getElementById(selectedCalendarTarget||'dateInput');if(target)target.value=toJalaliInput(iso).replaceAll('-','/');closeCalendar()}
function openChangePin(){document.getElementById('oldPin').value='';document.getElementById('newPin').value='';document.getElementById('newPin2').value='';document.getElementById('pinChangeError').textContent='';document.getElementById('changePinModal').style.display='flex'}
function closeChangePin(){document.getElementById('changePinModal').style.display='none'}
async function saveNewPin(){let old=document.getElementById('oldPin').value,n=document.getElementById('newPin').value,n2=document.getElementById('newPin2').value,e=document.getElementById('pinChangeError');if(!validPin(old)||await secureHash(old)!==localStorage.getItem(PIN_KEY)){e.textContent='رمز فعلی صحیح نیست.';return}if(!validPin(n)){e.textContent='رمز جدید باید ۴ تا ۸ رقم باشد.';return}if(n!==n2){e.textContent='تکرار رمز جدید مطابقت ندارد.';return}localStorage.setItem(PIN_KEY,await secureHash(n));e.textContent='رمز ورود با موفقیت تغییر کرد.';setTimeout(closeChangePin,700)}
let soundIsPlaying=false;function setSoundPlaying(v){soundIsPlaying=v;let p=document.getElementById('soundPreviewBtn'),st=document.getElementById('soundStopBtn');if(p)p.textContent=v?'▶ پخش دوباره':'▶ پخش آزمایشی';if(st)st.disabled=!v}
function toggleSoundPreview(){if(soundIsPlaying){stopSoundPreview();return}if(window.AndroidYada&&AndroidYada.previewNotificationSound){AndroidYada.previewNotificationSound();setSoundPlaying(true)}else alert('پیش‌شنوی صدا فقط در نسخه نصب‌شده اندروید در دسترس است.')}
function stopSoundPreview(){if(window.AndroidYada&&AndroidYada.stopNotificationSound)AndroidYada.stopNotificationSound();setSoundPlaying(false)}
async function checkNotificationAccess(){
 if(!window.AndroidYada){alert('این قابلیت فقط در نسخه نصب‌شده اندروید در دسترس است.');return}
 if(AndroidYada.hasNotificationPermission()){
  document.getElementById('notificationAccessStatus').textContent='مجوز نمایش اعلان فعال است.';
  if(AndroidYada.canScheduleExactAlarms&&AndroidYada.canScheduleExactAlarms())alert('مجوز اعلان و هشدار دقیق فعال هستند.');
  else if(await themedConfirm('اعلان فعال است، اما هشدار دقیق غیرفعال است. تنظیمات آن را باز کنم؟'))AndroidYada.requestExactAlarmPermission();
 }else{
  document.getElementById('notificationAccessStatus').textContent='مجوز اعلان غیرفعال است.';
  if(AndroidYada.requestNotificationPermission)AndroidYada.requestNotificationPermission();
  else if(AndroidYada.openNotificationSettings)AndroidYada.openNotificationSettings();
 }
}
function chooseNotificationSound(){if(window.AndroidYada&&AndroidYada.pickCustomAudio){AndroidYada.pickCustomAudio()}else{alert('انتخاب فایل صوتی فقط در نسخه نصب‌شده اندروید در دسترس است.')}}
function resetNotificationSound(){if(window.AndroidYada&&AndroidYada.resetNotificationSound)AndroidYada.resetNotificationSound();document.getElementById('soundStatus').textContent='صدای پیش‌فرض گوشی'}
function previewSound(){if(window.AndroidYada&&AndroidYada.previewNotificationSound)AndroidYada.previewNotificationSound();else alert('پیش‌شنوی صدا در نسخه نصب‌شده اندروید در دسترس است.')}
window.onNotificationSoundChosen=function(name){stopSoundPreview();let title=name||'صدای پیش‌فرض گوشی';document.getElementById('soundStatus').textContent='صدای انتخاب‌شده: '+title;localStorage.setItem('yadaSoundTitle',title)};
document.getElementById('vibrationToggle').checked=localStorage.getItem('yadaVibration')!=='0';if(window.AndroidYada)AndroidYada.setVibration(document.getElementById('vibrationToggle').checked);


function getSelectedEventTime(){let h=document.getElementById('timeHour').value,m=document.getElementById('timeMinute').value;if(h===''||m==='')return '';return String(h).padStart(2,'0')+':'+String(m).padStart(2,'0')}
function initTimePicker(){let h=document.getElementById('timeHour'),m=document.getElementById('timeMinute');for(let i=0;i<24;i++)h.innerHTML+=`<option value="${String(i).padStart(2,'0')}">${toFaDigits(String(i).padStart(2,'0'))}</option>`;for(let i=0;i<60;i++)m.innerHTML+=`<option value="${String(i).padStart(2,'0')}">${toFaDigits(String(i).padStart(2,'0'))}</option>`}
function formatClock(v){if(!v)return '';let [hh,mm]=v.split(':').map(Number);if(localStorage.getItem('yadaClockMode')==='12'){let suffix=hh>=12?' ب.ظ':' ق.ظ',h=hh%12||12;return `${toFaDigits(h)}:${toFaDigits(String(mm).padStart(2,'0'))}${suffix}`}return `${toFaDigits(String(hh).padStart(2,'0'))}:${toFaDigits(String(mm).padStart(2,'0'))}`}
function setClockMode(mode){localStorage.setItem('yadaClockMode',String(mode));updateClockButtons();render()}
function updateClockButtons(){let mode=localStorage.getItem('yadaClockMode')||'24';document.getElementById('clock24Btn').classList.toggle('clock-selected',mode==='24');document.getElementById('clock12Btn').classList.toggle('clock-selected',mode==='12')}

initTimePicker();updateClockButtons();
if(window.AndroidYada&&AndroidYada.getNotificationSoundTitle){let selected=AndroidYada.getNotificationSoundTitle()||'صدای پیش‌فرض گوشی';document.getElementById('soundStatus').textContent='صدای انتخاب‌شده: '+selected}else{let selected=localStorage.getItem('yadaSoundTitle');if(selected)document.getElementById('soundStatus').textContent='صدای انتخاب‌شده: '+selected}
render();
setInterval(()=>{if(document.getElementById('home')?.classList.contains('active'))render()},30000);

/* YADA 2.9.4 – themed dialogs, brighter surfaces and responsive finance navigation */
const yadaDialogStyle=document.createElement('style');yadaDialogStyle.textContent=`
.finance-tabs{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:7px;margin:13px 0 12px}
.finance-tabs button{min-width:0;padding:11px 3px;font-size:11px;white-space:nowrap}
.finance-tabs .overview-tab{grid-column:1/-1;order:3;padding:14px 8px;font-size:14px;letter-spacing:.1px}
.finance-tabs button:not(.overview-tab){order:1}
body[data-theme="light"] .finance-tabs button{background:linear-gradient(145deg,#fff,#f4eddf);color:#293a56}
body[data-theme="light"] .finance-tabs .overview-tab{background:#fff;color:#293a56;border-color:#ded4c1;box-shadow:none}
body[data-theme="light"] .finance-tabs .overview-tab.active{background:linear-gradient(120deg,#fff0b8,#f6ca67 55%,#d9a642);color:#101a2b;border-color:#ffe39a;box-shadow:0 0 12px #f4c65b2b}
:root{--gold:#ffd36c;--gold2:#ffe9a8;--line:#5478ad;--panel:#17365f;--panel2:#214879;--muted:#c2d2ed;--green:#52e0bd;--red:#ff8f91}
.hero{border-color:#ffd36c;box-shadow:inset 0 0 0 1px #fff0b855,0 0 19px #f4c65b55,0 12px 35px #06132c66}
body[data-theme="light"] .hero{box-shadow:none!important}
.tile{border-color:#5f8bc4;background:linear-gradient(145deg,#24518c 0%,#183c6c 54%,#102b50 100%);box-shadow:inset 0 1px 0 #ffffff35,0 0 12px #3d91ff20,0 8px 22px #020b1d55}
.finance-box,.finance-panel{border-color:#edc66b;background:linear-gradient(145deg,#1d4476,#10294d);box-shadow:inset 0 1px 0 #ffffff30,0 0 13px #f4c65b24,0 6px 18px #020b1d44}
.finance-balance{background:linear-gradient(135deg,#24578d,#10294d);border-color:#ffe08a}
.finance-box.income b,.finance-value.positive{color:#55e7c2}.finance-box.expense b,.finance-value.negative{color:#ff9691}
.finance-progress span{background:linear-gradient(90deg,#32e0bb,#ffe078,#ff9d6b)}
body[data-theme="light"] .tile{background:linear-gradient(145deg,#fff,#edf4ff);border-color:#aac4e7;box-shadow:0 7px 20px #476c9a17,inset 0 1px 0 #fff}
body[data-theme="light"] .finance-box,body[data-theme="light"] .finance-panel{border-color:#d8b96f;background:linear-gradient(145deg,#fff,#f5f0e5)}
body[data-theme="light"] .finance-balance{background:linear-gradient(135deg,#e6f0ff,#fff5d8);border-color:#d6b66f}
body[data-theme="light"] .finance-box.income b,body[data-theme="light"] .finance-value.positive{color:#087d69}body[data-theme="light"] .finance-box.expense b,body[data-theme="light"] .finance-value.negative{color:#bb4545}
#yadaDialogOverlay{position:fixed;inset:0;z-index:2000;display:none;align-items:center;justify-content:center;padding:22px;background:#030916b8;backdrop-filter:blur(7px)}
#yadaDialogOverlay.show{display:flex}#yadaDialogCard{width:min(100%,390px);border:1.5px solid var(--gold);border-radius:22px;padding:21px 18px 16px;background:linear-gradient(145deg,#1c3b67,#0e203c);color:#fff8e8;box-shadow:0 20px 60px #0009,inset 0 1px 0 #ffffff30}
#yadaDialogCard p{font-size:13px;line-height:2;margin:0 0 18px;white-space:pre-wrap}#yadaDialogActions{display:flex;gap:9px}#yadaDialogActions button{flex:1;border:0;border-radius:12px;padding:12px;font:inherit;font-size:12px}#yadaDialogOk{background:linear-gradient(120deg,#fff0b8,#f6ca67,#d9a642);color:#101a2b;font-weight:700}#yadaDialogCancel{background:#2b466a;color:#fff}
body[data-theme="light"] #yadaDialogCard{background:linear-gradient(145deg,#fff,#f3ecdf);color:#25334a;border-color:#d6b66f}body[data-theme="light"] #yadaDialogCancel{background:#e9e2d4;color:#273244}
.event{background:linear-gradient(120deg,#1b3d6b,#122a4c);border-color:#547db4;box-shadow:inset 0 1px 0 #ffffff16,0 5px 14px #020b1d30}
.month-card{border-color:#f0ca72;background:linear-gradient(145deg,#102b50,#174578 70%,#102a4c);box-shadow:inset 0 1px 0 #ffffff25,0 0 10px #3a9bdf20,0 5px 14px #020b1d50}
.sheet{background:linear-gradient(145deg,#1a365d,#10213c);border-color:#6387b8}
.primary{background:linear-gradient(120deg,#fff2bd,#ffd36c 48%,#e8ad45);box-shadow:0 4px 16px #f4c65b42,inset 0 1px 0 #fff}
body[data-theme="light"] .event{background:linear-gradient(120deg,#fff,#f1f6ff);border-color:#c4d4e8}
body[data-theme="light"] .month-card{background:linear-gradient(155deg,#fffdf8 0%,#f3ecdc 72%,#e8d4aa 100%)!important;border-color:#c9a45b!important;box-shadow:inset 0 1px 0 #fff,0 4px 12px #75634418!important}
body[data-theme="light"] .month-card:before{color:#9a7b4540}
body[data-theme="light"] .month-card b.month-name{color:#28364b;text-shadow:none}
body[data-theme="light"] .month-card .month-symbol-img{filter:drop-shadow(0 1px 2px #8d754033)}
body[data-theme="light"] .month-card:after{background:linear-gradient(90deg,#c39a4d,#f0d99e 48%,#c39a4d)!important;opacity:.7!important;box-shadow:inset 0 1px 3px #fff9}
body[data-theme="light"] .month-card .month-count{background:#fffaf0ef;color:#76551f;border-color:#c9a45b;box-shadow:0 1px 3px #75634420}
.finance-tabs button{order:0!important;grid-column:auto}
.finance-tabs button.overview-tab,.finance-tabs button.search-tab{grid-column:1/-1!important}
.finance-tabs .overview-tab{order:0!important;padding:11px 8px!important;font-size:12px!important}
.finance-tabs .search-tab{order:0!important}
body[data-theme="light"] .sheet{background:linear-gradient(145deg,#fff,#f4efe5);border-color:#d8c69c}
@media(max-width:380px){.finance-tabs{gap:5px}.finance-tabs button{font-size:10px;padding:10px 2px}}
`;
document.head.appendChild(yadaDialogStyle);
let yadaDialogQueue=Promise.resolve();
function themedDialog(message,confirmMode=false){return new Promise(resolve=>{const overlay=document.getElementById('yadaDialogOverlay')||(()=>{const o=document.createElement('div');o.id='yadaDialogOverlay';o.innerHTML='<div id="yadaDialogCard" role="dialog" aria-modal="true"><p id="yadaDialogMessage"></p><div id="yadaDialogActions"><button id="yadaDialogCancel" type="button">انصراف</button><button id="yadaDialogOk" type="button">تأیید</button></div></div>';document.body.appendChild(o);return o})();overlay.querySelector('#yadaDialogMessage').textContent=String(message??'');const cancel=overlay.querySelector('#yadaDialogCancel'),ok=overlay.querySelector('#yadaDialogOk');cancel.style.display=confirmMode?'block':'none';ok.textContent=confirmMode?'تأیید':'متوجه شدم';const finish=v=>{overlay.classList.remove('show');ok.onclick=null;cancel.onclick=null;resolve(v)};ok.onclick=()=>finish(true);cancel.onclick=()=>finish(false);overlay.onclick=e=>{if(e.target===overlay&&confirmMode)finish(false)};overlay.classList.add('show')})}
function themedConfirm(message){return themedDialog(message,true)}
window.alert=(message)=>{themedDialog(message,false)};

