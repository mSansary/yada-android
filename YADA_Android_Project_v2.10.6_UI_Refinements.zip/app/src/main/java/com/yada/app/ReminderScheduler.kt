package com.yada.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject

object ReminderScheduler {
    private const val PREFS = "yada_scheduled_reminders"
    private const val KEY = "items"
    private const val FIRED_PREFS = "yada_fired_reminders"
    private const val FIRED_KEY = "request_codes"

    fun canScheduleExact(context: Context): Boolean {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        return Build.VERSION.SDK_INT < 31 || alarm.canScheduleExactAlarms()
    }

    fun schedule(context: Context, title: String, timeMillis: Long, yearly: Boolean, monthly: Boolean = false): Boolean {
        if (timeMillis <= System.currentTimeMillis()) return false
        val requestCode = computeRequestCode(title, timeMillis)
        clearFired(context, requestCode)
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra("title", title)
            putExtra("yearly", yearly)
            putExtra("monthly", monthly)
            putExtra("time", timeMillis)
            putExtra("requestCode", requestCode)
        }
        val pending = PendingIntent.getBroadcast(
            context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val exact = canScheduleExact(context)
        if (exact) {
            if (Build.VERSION.SDK_INT >= 23) alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timeMillis, pending)
            else alarm.setExact(AlarmManager.RTC_WAKEUP, timeMillis, pending)
        } else {
            // Fallback is deliberately inexact; Android may defer it while the device is idle.
            if (Build.VERSION.SDK_INT >= 23) alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timeMillis, pending)
            else alarm.set(AlarmManager.RTC_WAKEUP, timeMillis, pending)
        }
        persist(context, requestCode, title, timeMillis, yearly, monthly)
        return exact
    }


    fun computeRequestCode(title: String, timeMillis: Long): Int = (timeMillis xor title.hashCode().toLong()).toInt()

    fun wasFired(context: Context, title: String, timeMillis: Long): Boolean {
        val requestCode = computeRequestCode(title, timeMillis)
        return context.getSharedPreferences(FIRED_PREFS, Context.MODE_PRIVATE)
            .getStringSet(FIRED_KEY, emptySet())?.contains(requestCode.toString()) == true
    }

    fun markFired(context: Context, requestCode: Int) {
        val prefs = context.getSharedPreferences(FIRED_PREFS, Context.MODE_PRIVATE)
        val fired = prefs.getStringSet(FIRED_KEY, emptySet())?.toMutableSet() ?: mutableSetOf()
        fired.add(requestCode.toString())
        prefs.edit().putStringSet(FIRED_KEY, fired).apply()
    }

    private fun clearFired(context: Context, requestCode: Int) {
        val prefs = context.getSharedPreferences(FIRED_PREFS, Context.MODE_PRIVATE)
        val fired = prefs.getStringSet(FIRED_KEY, emptySet())?.toMutableSet() ?: mutableSetOf()
        if (fired.remove(requestCode.toString())) prefs.edit().putStringSet(FIRED_KEY, fired).apply()
    }

    fun cancel(context: Context, title: String, timeMillis: Long) {
        val requestCode = computeRequestCode(title, timeMillis)
        val intent = Intent(context, ReminderReceiver::class.java)
        val pending = PendingIntent.getBroadcast(
            context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarm.cancel(pending)
        pending.cancel()
        remove(context, requestCode)
        clearFired(context, requestCode)
    }

    fun remove(context: Context, requestCode: Int) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val old = read(context)
        val updated = JSONArray()
        for (i in 0 until old.length()) {
            val item = old.optJSONObject(i) ?: continue
            if (item.optInt("requestCode") != requestCode) updated.put(item)
        }
        prefs.edit().putString(KEY, updated.toString()).apply()
    }

    fun restoreAll(context: Context) {
        val items = read(context)
        val now = System.currentTimeMillis()
        for (i in 0 until items.length()) {
            val item = items.optJSONObject(i) ?: continue
            val title = item.optString("title", "یادآوری یادا")
            val time = item.optLong("time", 0L)
            val yearly = item.optBoolean("yearly", false)
            if (time > now) schedule(context, title, time, yearly, item.optBoolean("monthly", false))
            else remove(context, item.optInt("requestCode"))
        }
    }

    private fun persist(context: Context, requestCode: Int, title: String, time: Long, yearly: Boolean, monthly: Boolean) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val old = read(context)
        val updated = JSONArray()
        for (i in 0 until old.length()) {
            val item = old.optJSONObject(i) ?: continue
            if (item.optInt("requestCode") != requestCode) updated.put(item)
        }
        updated.put(JSONObject().put("requestCode", requestCode).put("title", title).put("time", time).put("yearly", yearly).put("monthly", monthly))
        prefs.edit().putString(KEY, updated.toString()).apply()
    }

    private fun read(context: Context): JSONArray {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]")
        return try { JSONArray(raw) } catch (_: Exception) { JSONArray() }
    }
}
