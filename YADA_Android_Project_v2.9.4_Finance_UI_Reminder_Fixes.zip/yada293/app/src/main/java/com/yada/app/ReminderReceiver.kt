package com.yada.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import java.util.Calendar

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("title") ?: "یادآوری یادا"
        val requestCode = intent.getIntExtra("requestCode", 0)
        val yearly = intent.getBooleanExtra("yearly", false)
        val prefs = context.getSharedPreferences("yada_settings", Context.MODE_PRIVATE)
        val savedSound = prefs.getString("notification_sound", "")
        val soundUri = if (savedSound.isNullOrEmpty()) RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION) else Uri.parse(savedSound)
        val vibration = prefs.getBoolean("yada_vibration", true)
        val channelId = "yada_reminders_" + (savedSound ?: "default").hashCode().toString().replace('-', 'n') + if (vibration) "_v" else "_s"
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && manager.getNotificationChannel(channelId) == null) {
            val channel = NotificationChannel(channelId, "یادآوری‌های یادا", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "هشدارهای صوتی و لرزشی یادا"
                setSound(soundUri, null)
                enableVibration(vibration)
            }
            manager.createNotificationChannel(channel)
        }
        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("یادا")
            .setContentText(title)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setSound(soundUri)
            .setVibrate(if (vibration) longArrayOf(0, 300, 150, 300) else null)
            .build()
        manager.notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), notification)

        if (yearly) {
            ReminderScheduler.remove(context, requestCode)
            val next = Calendar.getInstance().apply {
                timeInMillis = intent.getLongExtra("time", System.currentTimeMillis())
                add(Calendar.YEAR, 1)
            }
            ReminderScheduler.schedule(context, title, next.timeInMillis, true)
        } else {
            ReminderScheduler.remove(context, requestCode)
        }
    }
}
