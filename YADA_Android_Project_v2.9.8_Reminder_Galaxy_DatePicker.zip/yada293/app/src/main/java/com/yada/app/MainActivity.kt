package com.yada.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebSettings
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.fragment.app.FragmentActivity

class MainActivity : FragmentActivity() {
    private val ringtoneRequest = 2401
    private val customAudioRequest = 2402
    private lateinit var yadaWeb: WebView
    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(11, 18, 34)
        window.navigationBarColor = android.graphics.Color.rgb(11, 18, 34)
        // Hide only the status bar: this gives the home header/logo a clean full-height canvas.
        window.setFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN,
            android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN)
        requestNotificationPermission()
        val web = WebView(this)
        yadaWeb = web
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.cacheMode = WebSettings.LOAD_DEFAULT
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                view?.evaluateJavascript("if(window.render){render();window.scrollTo(0,0)}", null)
            }
        }
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(YadaBridge(this, web), "AndroidYada")
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
    }

    override fun onResume() {
        super.onResume()
        if (::yadaWeb.isInitialized) {
            ReminderScheduler.restoreAll(this)
            yadaWeb.post { yadaWeb.evaluateJavascript("if(window.render){render()} ", null) }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == ringtoneRequest && resultCode == Activity.RESULT_OK) {
            val uri = data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            val title = uri?.let { RingtoneManager.getRingtone(this, it)?.getTitle(this) } ?: "صدای پیش‌فرض گوشی"
            getSharedPreferences("yada_settings", Context.MODE_PRIVATE).edit()
                .putString("notification_sound", uri?.toString() ?: "")
                .putString("notification_sound_title", title).apply()
            yadaWeb.evaluateJavascript("window.onNotificationSoundChosen && window.onNotificationSoundChosen(" + org.json.JSONObject.quote(title) + ")", null)
        } else if (requestCode == customAudioRequest && resultCode == Activity.RESULT_OK) {
            val uri = data?.data ?: return
            try {
                val flags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                contentResolver.takePersistableUriPermission(uri, flags and Intent.FLAG_GRANT_READ_URI_PERMISSION)
                val title = queryDisplayName(uri) ?: uri.lastPathSegment ?: "صدای انتخاب‌شده"
                getSharedPreferences("yada_settings", Context.MODE_PRIVATE).edit()
                    .putString("notification_sound", uri.toString())
                    .putString("notification_sound_title", title).apply()
                yadaWeb.evaluateJavascript("window.onNotificationSoundChosen && window.onNotificationSoundChosen(" + org.json.JSONObject.quote(title) + ")", null)
            } catch (e: Exception) {
                android.widget.Toast.makeText(this, "دسترسی به فایل صوتی ممکن نشد؛ دوباره انتخابش کن.", android.widget.Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun queryDisplayName(uri: Uri): String? = try {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    } catch (_: Exception) { null }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }
}

class YadaBridge(private val activity: FragmentActivity, private val web: WebView) {
    private val context: Context get() = activity
    private var previewRingtone: android.media.Ringtone? = null

    @JavascriptInterface
    fun setSystemBarsLight(light: Boolean) {
        activity.runOnUiThread {
            val color = if (light) android.graphics.Color.rgb(244, 241, 233) else android.graphics.Color.rgb(11, 18, 34)
            activity.window.statusBarColor = color
            activity.window.navigationBarColor = color
            if (Build.VERSION.SDK_INT >= 23) {
                var flags = activity.window.decorView.systemUiVisibility
                flags = if (light) flags or android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                    else flags and android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
                if (Build.VERSION.SDK_INT >= 26) {
                    flags = if (light) flags or android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
                        else flags and android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
                }
                activity.window.decorView.systemUiVisibility = flags
            }
        }
    }

    @JavascriptInterface
    fun biometricAvailable(): Boolean {
        return BiometricManager.from(context).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS
    }

    @JavascriptInterface
    fun authenticateBiometric() {
        activity.runOnUiThread {
            if (!biometricAvailable()) {
                web.evaluateJavascript("window.onBiometricResult && window.onBiometricResult(false)", null)
                return@runOnUiThread
            }
            val prompt = BiometricPrompt(activity, ContextCompat.getMainExecutor(activity),
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                        web.evaluateJavascript("window.onBiometricResult && window.onBiometricResult(true)", null)
                    }
                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                        web.evaluateJavascript("window.onBiometricResult && window.onBiometricResult(false)", null)
                    }
                    override fun onAuthenticationFailed() {
                        web.evaluateJavascript("window.onBiometricResult && window.onBiometricResult(false)", null)
                    }
                })
            val info = BiometricPrompt.PromptInfo.Builder()
                .setTitle("ورود به یادا")
                .setSubtitle("برای ورود، از اثر انگشت یا روش زیست‌سنجی گوشی استفاده کن")
                .setNegativeButtonText("ورود با کد")
                .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK)
                .build()
            prompt.authenticate(info)
        }
    }

    @JavascriptInterface
    fun pickNotificationSound() {
        activity.runOnUiThread {
            val current = context.getSharedPreferences("yada_settings", Context.MODE_PRIVATE).getString("notification_sound", "")
            val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_NOTIFICATION)
                putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "انتخاب صدای اعلان یادا")
                putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true)
                putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                if (!current.isNullOrEmpty()) putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(current))
            }
            activity.startActivityForResult(intent, 2401)
        }
    }

    @JavascriptInterface
    fun resetNotificationSound() {
        context.getSharedPreferences("yada_settings", Context.MODE_PRIVATE).edit()
            .putString("notification_sound", "")
            .putString("notification_sound_title", "صدای پیش‌فرض گوشی").apply()
    }

    @JavascriptInterface
    fun pickCustomAudio() {
        activity.runOnUiThread {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "audio/*"
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }
            activity.startActivityForResult(intent, 2402)
        }
    }

    @JavascriptInterface
    fun getNotificationSoundTitle(): String {
        return context.getSharedPreferences("yada_settings", Context.MODE_PRIVATE)
            .getString("notification_sound_title", "صدای پیش‌فرض گوشی") ?: "صدای پیش‌فرض گوشی"
    }

    @JavascriptInterface
    fun setVibration(enabled: Boolean) {
        context.getSharedPreferences("yada_settings", Context.MODE_PRIVATE).edit().putBoolean("yada_vibration", enabled).apply()
    }

    @JavascriptInterface
    fun previewNotificationSound() {
        activity.runOnUiThread {
            stopNotificationSound()
            val saved = context.getSharedPreferences("yada_settings", Context.MODE_PRIVATE).getString("notification_sound", "")
            val uri = if (saved.isNullOrEmpty()) RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION) else Uri.parse(saved)
            try {
                previewRingtone = RingtoneManager.getRingtone(context, uri)
                previewRingtone?.play()
            } catch (_: Exception) {
                previewRingtone = null
                android.widget.Toast.makeText(context, "پخش پیش‌نمایش این فایل ممکن نیست؛ فایل صوتی دیگری انتخاب کن.", android.widget.Toast.LENGTH_LONG).show()
            }
        }
    }

    @JavascriptInterface
    fun stopNotificationSound() {
        activity.runOnUiThread {
            previewRingtone?.stop()
            previewRingtone = null
        }
    }

    @JavascriptInterface
    fun requestNotificationPermission() {
        activity.runOnUiThread {
            if (Build.VERSION.SDK_INT >= 33 && !hasNotificationPermission()) {
                ActivityCompat.requestPermissions(activity, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
            } else {
                openNotificationSettings()
            }
        }
    }

    @JavascriptInterface
    fun openNotificationSettings() {
        activity.runOnUiThread {
            try {
                val intent = Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                    putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, context.packageName)
                }
                activity.startActivity(intent)
            } catch (_: Exception) {
                val intent = Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + context.packageName))
                activity.startActivity(intent)
            }
        }
    }

    @JavascriptInterface
    fun hasNotificationPermission(): Boolean {
        return Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    }

    @JavascriptInterface
    fun canScheduleExactAlarms(): Boolean = ReminderScheduler.canScheduleExact(context)

    @JavascriptInterface
    fun requestExactAlarmPermission() {
        if (Build.VERSION.SDK_INT >= 31 && !ReminderScheduler.canScheduleExact(context)) {
            try {
                val intent = Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                    data = Uri.parse("package:" + context.packageName)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            } catch (_: Exception) { }
        }
    }

    @JavascriptInterface
    fun scheduleReminder(title: String, timeMillis: Long, yearly: Boolean): Boolean {
        return ReminderScheduler.schedule(context, title, timeMillis, yearly)
    }

    @JavascriptInterface
    fun cancelReminder(title: String, timeMillis: Long) {
        ReminderScheduler.cancel(context, title, timeMillis)
    }

    @JavascriptInterface
    fun wasReminderFired(title: String, timeMillis: Long): Boolean {
        return ReminderScheduler.wasFired(context, title, timeMillis)
    }
}
