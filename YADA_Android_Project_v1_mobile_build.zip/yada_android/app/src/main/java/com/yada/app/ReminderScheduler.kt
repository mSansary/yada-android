package com.yada.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

object ReminderScheduler {
    fun schedule(context: Context, title: String, timeMillis: Long, yearly: Boolean) {
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra("title", title)
            putExtra("yearly", yearly)
            putExtra("time", timeMillis)
        }
        val requestCode = (timeMillis xor title.hashCode().toLong()).toInt()
        val pending = PendingIntent.getBroadcast(context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= 23) alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timeMillis, pending)
        else alarm.set(AlarmManager.RTC_WAKEUP, timeMillis, pending)
    }
}
