package com.yada.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebSettings
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.fragment.app.FragmentActivity

class MainActivity : FragmentActivity() {
    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(11, 18, 34)
        window.navigationBarColor = android.graphics.Color.rgb(11, 18, 34)
        requestNotificationPermission()
        val web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.cacheMode = WebSettings.LOAD_DEFAULT
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(YadaBridge(this, web), "AndroidYada")
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }
}

class YadaBridge(private val activity: FragmentActivity, private val web: WebView) {
    private val context: Context get() = activity

    @JavascriptInterface
    fun biometricAvailable(): Boolean {
        return BiometricManager.from(context).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS
    }

    @JavascriptInterface
    fun authenticateBiometric() {
        activity.runOnUiThread {
            if (!biometricAvailable()) {
                web.evaluateJavascript("window.onBiometricResult && window.onBiometricResult(false)", null)
                return@runOnUiThread
            }
            val prompt = BiometricPrompt(activity, ContextCompat.getMainExecutor(activity),
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                        web.evaluateJavascript("window.onBiometricResult && window.onBiometricResult(true)", null)
                    }
                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                        web.evaluateJavascript("window.onBiometricResult && window.onBiometricResult(false)", null)
                    }
                    override fun onAuthenticationFailed() {
                        web.evaluateJavascript("window.onBiometricResult && window.onBiometricResult(false)", null)
                    }
                })
            val info = BiometricPrompt.PromptInfo.Builder()
                .setTitle("ورود به یادا")
                .setSubtitle("برای ورود، از اثر انگشت یا روش زیست‌سنجی گوشی استفاده کن")
                .setNegativeButtonText("ورود با کد")
                .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK)
                .build()
            prompt.authenticate(info)
        }
    }

    @JavascriptInterface
    fun scheduleReminder(title: String, timeMillis: Long, yearly: Boolean) {
        ReminderScheduler.schedule(context, title, timeMillis, yearly)
    }
}
