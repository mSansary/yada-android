package com.yada.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebSettings
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.fragment.app.FragmentActivity

class MainActivity : FragmentActivity() {
    private val ringtoneRequest = 2401
    private lateinit var yadaWeb: WebView
    @Suppress("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(11, 18, 34)
        window.navigationBarColor = android.graphics.Color.rgb(11, 18, 34)
        requestNotificationPermission()
        val web = WebView(this)
        yadaWeb = web
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.cacheMode = WebSettings.LOAD_DEFAULT
        web.webViewClient = WebViewClient()
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(YadaBridge(this, web), "AndroidYada")
        web.loadUrl("file:///android_asset/index.html")
        setContentView(web)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == ringtoneRequest && resultCode == Activity.RESULT_OK) {
            val uri = data?.getParcelableExtra<Uri>(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            getSharedPreferences("yada_settings", Context.MODE_PRIVATE).edit().putString("notification_sound", uri?.toString() ?: "").apply()
            val title = uri?.let { RingtoneManager.getRingtone(this, it)?.getTitle(this) } ?: "صدای پیش‌فرض گوشی"
            yadaWeb.evaluateJavascript("window.onNotificationSoundChosen && window.onNotificationSoundChosen(" + org.json.JSONObject.quote(title) + ")", null)
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 100)
        }
    }
}

class YadaBridge(private val activity: FragmentActivity, private val web: WebView) {
    private val context: Context get() = activity
    private var previewRingtone: android.media.Ringtone? = null

    @JavascriptInterface
    fun biometricAvailable(): Boolean {
        return BiometricManager.from(context).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS
    }

    @JavascriptInterface
    fun authenticateBiometric() {
        activity.runOnUiThread {
            if (!biometricAvailable()) {
                web.evaluateJavascript("window.onBiometricResult && window.onBiometricResult(false)", null)
                return@runOnUiThread
            }
            val prompt = BiometricPrompt(activity, ContextCompat.getMainExecutor(activity),
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                        web.evaluateJavascript("window.onBiometricResult && window.onBiometricResult(true)", null)
                    }
                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                        web.evaluateJavascript("window.onBiometricResult && window.onBiometricResult(false)", null)
                    }
                    override fun onAuthenticationFailed() {
                        web.evaluateJavascript("window.onBiometricResult && window.onBiometricResult(false)", null)
                    }
                })
            val info = BiometricPrompt.PromptInfo.Builder()
                .setTitle("ورود به یادا")
                .setSubtitle("برای ورود، از اثر انگشت یا روش زیست‌سنجی گوشی استفاده کن")
                .setNegativeButtonText("ورود با کد")
                .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK)
                .build()
            prompt.authenticate(info)
        }
    }

    @JavascriptInterface
    fun pickNotificationSound() {
        activity.runOnUiThread {
            val current = context.getSharedPreferences("yada_settings", Context.MODE_PRIVATE).getString("notification_sound", "")
            val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_NOTIFICATION)
                putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "انتخاب صدای اعلان یادا")
                putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true)
                putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                if (!current.isNullOrEmpty()) putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(current))
            }
            activity.startActivityForResult(intent, 2401)
        }
    }

    @JavascriptInterface
    fun setVibration(enabled: Boolean) {
        context.getSharedPreferences("yada_settings", Context.MODE_PRIVATE).edit().putBoolean("yada_vibration", enabled).apply()
    }

    @JavascriptInterface
    fun previewNotificationSound() {
        activity.runOnUiThread {
            stopNotificationSound()
            val saved = context.getSharedPreferences("yada_settings", Context.MODE_PRIVATE).getString("notification_sound", "")
            val uri = if (saved.isNullOrEmpty()) RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION) else Uri.parse(saved)
            previewRingtone = RingtoneManager.getRingtone(context, uri)
            previewRingtone?.play()
        }
    }

    @JavascriptInterface
    fun stopNotificationSound() {
        activity.runOnUiThread {
            previewRingtone?.stop()
            previewRingtone = null
        }
    }

    @JavascriptInterface
    fun scheduleReminder(title: String, timeMillis: Long, yearly: Boolean) {
        ReminderScheduler.schedule(context, title, timeMillis, yearly)
    }
}
